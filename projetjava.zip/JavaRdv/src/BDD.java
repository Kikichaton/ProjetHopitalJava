import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class BDD {
	public ResultSet AfficherRdv() {
		
		String url="jdbc:mysql://localhost/hopitaljava?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
		String user="root";
		String password ="";
		
		try {
			Connection cnx = DriverManager.getConnection(url,user,password);
			Statement stmt = cnx.createStatement();
	        ResultSet rs;    
	        rs = stmt.executeQuery("SELECT * FROM rendezvous WHERE idRdv=42");
			return rs;

		}catch (SQLException e) {
			System.out.println("Une erreur est survenue lors de la connexion a la base de donn�es");
			e.printStackTrace();
			
		}
		return null;
}
	public ResultSet CountIdRdv() {
		String url="jdbc:mysql://localhost/hopitaljava?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
		String user="root";
		String password ="";
		
		try {
			Connection cnx = DriverManager.getConnection(url,user,password);
			Statement stmt = cnx.createStatement();
	        ResultSet rs;    
	        rs = stmt.executeQuery("SELECT count(idRdv) FROM rendezvous");
			return rs;

		}catch (SQLException e) {
			System.out.println("Une erreur est survenue lors de la connexion a la base de donn�es");
			e.printStackTrace();
			
		}
		return null;
		
	}
}
