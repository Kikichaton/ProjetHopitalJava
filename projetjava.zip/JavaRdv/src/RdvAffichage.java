import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

public class RdvAffichage {

	protected Shell shell;
	private Table table;
	private TableItem tableItem;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			RdvAffichage window = new RdvAffichage();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(900, 577);
		shell.setText("SWT Application");
		
		table = new Table(shell, SWT.BORDER | SWT.FULL_SELECTION);
		table.setBounds(36, 43, 600, 450);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		
		TableColumn tblclmnId = new TableColumn(table, SWT.NONE);
		tblclmnId.setWidth(100);
		tblclmnId.setText("idRdv");
		
		TableColumn tblclmnIddoc = new TableColumn(table, SWT.NONE);
		tblclmnIddoc.setWidth(100);
		tblclmnIddoc.setText("Docteur");

		TableColumn tblclmnIdPatient = new TableColumn(table, SWT.NONE);
		tblclmnIdPatient.setWidth(100);
		tblclmnIdPatient.setText("Patient");
		
		TableColumn tblclmnHoraire = new TableColumn(table, SWT.NONE);
		tblclmnHoraire.setWidth(100);
		tblclmnHoraire.setText("horaire");
		
		TableColumn tblclmnDate = new TableColumn(table, SWT.NONE);
		tblclmnDate.setWidth(100);
		tblclmnDate.setText("Date");
		
		TableColumn tblclmnMotif = new TableColumn(table, SWT.NONE);
		tblclmnMotif.setWidth(100);
		tblclmnMotif.setText("Motif");
		
		table.setHeaderVisible(true);
		table.setLinesVisible(true); 
		TableItem ligne1 = new TableItem(table,SWT.NONE);
		ligne1.setText(new String[] {"valeur 1 1","valeur 1 2", "valeur 1 3", "valeur 1 4", "valeur 1 5", "valeur 1 6" });
		TableItem ligne2 = new TableItem(table,SWT.NONE);
		ligne2.setText(new String[] {"valeur 1 1","valeur 1 2",  "valeur 1 3", "valeur 1 4", "valeur 1 5", "valeur 1 6"});
		TableItem ligne3 = new TableItem(table,SWT.NONE);
		ligne3.setText(new String[] {"valeur 1 1","valeur 1 2",  "valeur 1 3", "valeur 1 4", "valeur 1 5", "valeur 1 6"});



	}
}
