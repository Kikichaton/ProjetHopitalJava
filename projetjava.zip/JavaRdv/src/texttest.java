import java.sql.ResultSet;
import java.sql.SQLException;

public class texttest {
	public static void main(String[] args) {
		
		BDD MaBDD = new BDD();
		ResultSet batiste = MaBDD.AfficherRdv();
		try {
			while(batiste.next()) {
			System.out.println(batiste.getString("idRdv"));
			System.out.println(batiste.getString("idDoc"));
			System.out.println(batiste.getString("idPatient"));
			System.out.println(batiste.getString("horaire"));
			System.out.println(batiste.getString("date"));
			System.out.println(batiste.getString("motif"));

}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

}
}
